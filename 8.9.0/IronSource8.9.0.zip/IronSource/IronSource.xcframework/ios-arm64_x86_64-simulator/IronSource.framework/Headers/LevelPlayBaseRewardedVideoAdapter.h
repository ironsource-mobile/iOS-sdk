//
//  LevelPlayBaseRewardedVideoAdapter.h
//  Pods
//
//  Created by Maoz Elbaz on 09/05/2025.
//

#ifndef LevelPlayBaseRewardedVideoAdapter_h
#define LevelPlayBaseRewardedVideoAdapter_h

#import "ISBaseRewardedVideo.h"
#import "ISBiddingDataProtocol.h"
NS_ASSUME_NONNULL_BEGIN

@interface LevelPlayBaseRewardedVideoAdapter : ISBaseRewardedVideo <ISBiddingDataProtocol>

@end

NS_ASSUME_NONNULL_END

#endif /* LevelPlayBaseRewardedVideoAdapter_h */
