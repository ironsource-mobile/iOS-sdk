//
//  Copyright © 2017 IronSource. All rights reserved.
//

#ifndef ISEventsReporting_h
#define ISEventsReporting_h

#import <Foundation/Foundation.h>

DEPRECATED_MSG_ATTRIBUTE("This class will be made private in version 9.0.0.")
@interface ISEventsReporting : NSObject

+ (void)reportAppStarted DEPRECATED_MSG_ATTRIBUTE("");

@end

#endif
