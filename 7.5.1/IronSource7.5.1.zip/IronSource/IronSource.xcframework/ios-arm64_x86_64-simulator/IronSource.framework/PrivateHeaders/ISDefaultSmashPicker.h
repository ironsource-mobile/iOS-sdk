//
//  ISDefaultSmashPicker.h
//  IronSource
//
//  Created by Asaf Gur on 25/06/2023.
//  Copyright © 2023 IronSource. All rights reserved.
//

#import "ISWaterfallSmashPicker.h"

NS_ASSUME_NONNULL_BEGIN

@interface ISDefaultSmashPicker : ISWaterfallSmashPicker

@end

NS_ASSUME_NONNULL_END
