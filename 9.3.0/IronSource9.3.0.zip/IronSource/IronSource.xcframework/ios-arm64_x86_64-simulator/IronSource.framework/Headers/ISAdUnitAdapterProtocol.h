//
//  ISAdUnitAdapterProtocol.h
//  IronSource
//
//  Copyright © 2023 IronSource. All rights reserved.
//

#import "ISNetworkInitCallbackProtocol.h"

@protocol ISAdUnitAdapterProtocol <ISNetworkInitCallbackProtocol>

@end
