//
//  SSEScreenContext.h
//  Environment
//
//  Created by Mira Weiss on 30/03/2016.
//  Copyright © 2016 Supersonic. All rights reserved.
//

#import <Foundation/Foundation.h>
@import CoreGraphics;

@interface SSEScreenContext : NSObject

+ (CGFloat) scale;

@end
