//
//  ISNSupersonicAdsPublisherSwiftFacade.h
//  IronSource
//
//  Created by Idan Ginat on 03/01/2024.
//

#import <Foundation/Foundation.h>

@interface ISNSupersonicAdsPublisherSwiftFacade : NSObject

- (void)setControllerConfig:(NSString *)config;

@end
