//
//  NSUnitDuration+ISTimeUnit.h
//  Environment
//
//  Created by Liron Matityahu on 08/02/2023.
//
#import <Foundation/Foundation.h>

@interface NSUnitDuration (ISTimeUnit)

@property(class, readonly, copy) NSUnitDuration *ms;

@end
