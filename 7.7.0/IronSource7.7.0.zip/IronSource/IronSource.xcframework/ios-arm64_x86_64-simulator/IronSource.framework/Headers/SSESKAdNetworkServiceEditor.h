#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SSESKAdNetworkServiceEditor <NSObject>

@property(nonatomic, assign) BOOL shouldUseIdfv;

@end

NS_ASSUME_NONNULL_END
