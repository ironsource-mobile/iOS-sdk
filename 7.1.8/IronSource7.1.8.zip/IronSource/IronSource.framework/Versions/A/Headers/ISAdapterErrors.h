//
//  AdapterErrors.h
//  IronSource
//
//  Created by Guy Lis on 05/07/2021.
//  Copyright © 2021 IronSource. All rights reserved.
//

#ifndef AdapterErrors_h
#define AdapterErrors_h


typedef NS_ENUM(NSInteger, ISAdapterErrors) {
    ERROR_INTERNAL = 1000, // internal error
    ERROR_AD_EXPIRED = 1001, // expired ad error
    ERROR_MISSING_PARAMS = 1002 // missing parameters error

};


#endif /* AdapterErrors_h */
